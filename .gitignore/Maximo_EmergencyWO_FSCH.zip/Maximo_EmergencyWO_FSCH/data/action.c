Action()
{

	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		LAST);

	lr_think_time(18);

	lr_start_transaction("Login");

	web_submit_data("login", 
		"Action=http://porud755/maximo/ui/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=allowinsubframe", "Value=null", ENDITEM, 
		"Name=mobile", "Value=false", ENDITEM, 
		"Name=login", "Value=jsp", ENDITEM, 
		"Name=loginstamp", "Value=1526721557658", ENDITEM, 
		"Name=username", "Value=SP51532", ENDITEM, 
		"Name=password", "Value=Deepya!1", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("GotoWorkorder");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(4);

	web_submit_data("maximo.jsp", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx45", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_url("ui", 
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("GotoWorkorder",LR_AUTO);

	lr_start_transaction("NewWO");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(16);

	web_submit_data("maximo.jsp_2", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx527", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx314\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("NewWO",LR_AUTO);

	lr_start_transaction("JobType");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_3", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1025", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1026\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_4", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1793[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1793[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("JobType",LR_AUTO);

	lr_start_transaction("JobPriority");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(16);

	web_submit_data("maximo.jsp_5", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1274", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1275\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_6", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx2015[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2015[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("JobPriority",LR_AUTO);

	lr_start_transaction("Startdate");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("blank.html", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(7);

	web_custom_request("maximo.jsp_7", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5&currentfocus=mx1162&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1162%22%2C%22value%22%3A%2221%2F05%2F2018%2014%3A30%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2221%2F05%2F2018%2014%3A30%3A00%22%2C%22csrftokenholder%22%3A%226k544bfh8i0h8rfj5656r8noj5%22%7D%5D", 
		LAST);

	lr_end_transaction("Startdate",LR_AUTO);

	lr_start_transaction("EndDate");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(18);

	web_custom_request("maximo.jsp_8", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5&currentfocus=mx1170&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1170%22%2C%22value%22%3A%2222%2F05%2F2018%2014%3A15%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2222%2F05%2F2018%2014%3A15%3A00%22%2C%22csrftokenholder%22%3A%226k544bfh8i0h8rfj5656r8noj5%22%7D%5D", 
		LAST);

	lr_end_transaction("EndDate",LR_AUTO);

	lr_start_transaction("ClkonAddress");

	web_add_header("xhrseqnum", 
		"8");

	lr_think_time(12);

	web_submit_data("maximo.jsp_9", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1170", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx297\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonAddress",LR_AUTO);

	lr_start_transaction("ClkonNewRow");

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(14);

	web_submit_data("maximo.jsp_10", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx2187", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2187\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonNewRow",LR_AUTO);

	lr_start_transaction("ClkonGotoMeter");

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_11", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2246\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"11");

	web_submit_data("maximo.jsp_12", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_13", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonGotoMeter",LR_AUTO);

	lr_start_transaction("London");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"3");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(17);

	web_submit_data("maximo.jsp_14", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx538", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx538\",\"value\":\"London\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins/tivoli09/images/dialogclose.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/tabClose.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_think_time(15);

	web_submit_data("1526721769925", 
		"Action=http://porud755/maximo/ui/1526721769925?checkhiddenandconnection=true&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_add_header("xhrseqnum", 
		"2");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");

	web_submit_data("maximo.jsp_15", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx538", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopquerycheck\",\"targetId\":\"query_longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/qf_clear.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("London",LR_AUTO);

	lr_start_transaction("SelectCoutry");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(28);

	web_submit_data("maximo.jsp_16", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx93", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx93\",\"value\":\"W114594078\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"},{\"type\":\"click\",\"targetId\":\"mx95\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/st_MessageCritical.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(6);

	web_submit_data("maximo.jsp_17", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx791", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx791\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectCoutry",LR_AUTO);

	lr_start_transaction("ProvideCountry");

	web_add_header("xhrseqnum", 
		"5");

	lr_think_time(29);

	web_submit_data("maximo.jsp_18", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx454", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx454\",\"value\":\"546,431,208\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ProvideCountry",LR_AUTO);

	lr_start_transaction("SelectMPRN");

	web_add_header("xhrseqnum", 
		"6");

	lr_think_time(18);

	web_submit_data("maximo.jsp_19", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx576[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx576[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectMPRN",LR_AUTO);

	lr_start_transaction("ReturnValue");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(16);

	web_submit_data("maximo.jsp_20", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx282", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_21", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ReturnValue",LR_AUTO);

	lr_start_transaction("Plans");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");

	lr_think_time(17);

	web_submit_data("maximo.jsp_22", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/maximize.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/col_sort_asc.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_row_unselect.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/btn_garbage.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("Plans",LR_AUTO);

	lr_start_transaction("SelectLabor");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(20);

	web_submit_data("maximo.jsp_23", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx5807[R:0]\",\"value\":\"\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"},{\"type\":\"click\",\"targetId\":\"mx5856[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_find.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("SelectLabor",LR_AUTO);

	lr_start_transaction("GotoLabor");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(15);

	web_submit_data("maximo.jsp_24", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_25", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoLabor",LR_AUTO);

	lr_start_transaction("ClkonLabor");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"5");

	lr_think_time(23);

	web_submit_data("maximo.jsp_26", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx385\",\"value\":\"1\",\"requestType\":\"SYNC\",\"multi\":\"true\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonLabor",LR_AUTO);

	lr_start_transaction("SelectLabor");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(33);

	web_submit_data("maximo.jsp_27", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx628[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx628[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_showvalue.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_checkedreadonly.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("SelectLabor",LR_AUTO);

	lr_start_transaction("Returvalue");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(17);

	web_submit_data("maximo.jsp_28", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx298", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx298\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_29", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Returvalue",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"6");

	lr_think_time(16);

	web_submit_data("maximo.jsp_30", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Selectoption");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_31", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7214", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7215\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_32", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7214", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Selectoption",LR_AUTO);

	lr_start_transaction("ClkonOk");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(13);

	web_submit_data("maximo.jsp_33", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7269", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7269\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_34", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7269", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonOk",LR_AUTO);

	lr_start_transaction("ClkChangestatus");

	web_add_header("xhrseqnum", 
		"6");

	lr_think_time(27);

	web_submit_data("maximo.jsp_35", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkChangestatus",LR_AUTO);

	lr_start_transaction("Changestatus_Dispatch");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(29);

	web_submit_data("maximo.jsp_36", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7377", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7378\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_37", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7377", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_DISPATCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_Dispatch",LR_AUTO);

	lr_start_transaction("ClkOk_Dispatch");

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(18);

	web_submit_data("maximo.jsp_38", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7432\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_39", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"11");

	web_submit_data("maximo.jsp_40", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"12");

	web_submit_data("maximo.jsp_41", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"13");

	web_submit_data("maximo.jsp_42", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"14");

	web_submit_data("maximo.jsp_43", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7432", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkOk_Dispatch",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"15");

	lr_think_time(19);

	web_submit_data("maximo.jsp_44", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Changestatus_Accept");

	web_add_header("xhrseqnum", 
		"16");

	lr_think_time(32);

	web_submit_data("maximo.jsp_45", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7548", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7549\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"17");

	web_submit_data("maximo.jsp_46", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7548", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ACCEPT_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_Accept",LR_AUTO);

	lr_start_transaction("Clkok_Accept");

	web_add_header("xhrseqnum", 
		"18");

	lr_think_time(13);

	web_submit_data("maximo.jsp_47", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7603", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7603\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"19");

	web_submit_data("maximo.jsp_48", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7603", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_start_transaction("BacktoWO");

	web_add_header("xhrseqnum", 
		"20");

	lr_think_time(14);

	web_submit_data("maximo.jsp_49", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx279\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("BacktoWO",LR_AUTO);

	lr_start_transaction("Changedetails");

	web_add_header("xhrseqnum", 
		"21");

	lr_think_time(17);

	web_submit_data("maximo.jsp_50", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1473", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1474\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"22");

	web_submit_data("maximo.jsp_51", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7789[R:1]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7789[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"23");

	web_submit_data("maximo.jsp_52", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1481", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1482\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"24");

	web_submit_data("maximo.jsp_53", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx7970[R:1]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7970[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"25");

	web_submit_data("maximo.jsp_54", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1493\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"26");

	web_submit_data("maximo.jsp_55", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8151[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8151[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changedetails",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"27");

	lr_think_time(21);

	web_submit_data("maximo.jsp_56", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Changestatus_Complete");

	web_add_header("xhrseqnum", 
		"28");

	lr_think_time(35);

	web_submit_data("maximo.jsp_57", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8254", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8255\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"29");

	lr_think_time(4);

	web_submit_data("maximo.jsp_58", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8254", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ONSITE_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"30");

	lr_think_time(5);

	web_submit_data("maximo.jsp_59", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8309", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8309\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"31");

	web_submit_data("maximo.jsp_60", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8309", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_Complete",LR_AUTO);

	lr_start_transaction("ClkonChangestatus_COMP");

	web_add_header("xhrseqnum", 
		"32");

	lr_think_time(18);

	web_submit_data("maximo.jsp_61", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus_COMP",LR_AUTO);

	lr_start_transaction("Changestatus_COMP");

	web_add_header("xhrseqnum", 
		"33");

	lr_think_time(13);

	web_submit_data("maximo.jsp_62", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8417", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8418\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"34");

	web_submit_data("maximo.jsp_63", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8417", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_COMP_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_COMP",LR_AUTO);

	lr_start_transaction("Clkok_COMP");

	web_add_header("xhrseqnum", 
		"35");

	lr_think_time(14);

	web_submit_data("maximo.jsp_64", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8472", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8472\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"36");

	web_submit_data("maximo.jsp_65", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8472", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"37");

	lr_think_time(21);

	web_submit_data("maximo.jsp_66", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8520", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8520\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"38");

	web_submit_data("maximo.jsp_67", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8474", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8474\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Clkok_COMP",LR_AUTO);

	lr_start_transaction("ClkonCompletion");

	web_add_header("xhrseqnum", 
		"39");

	lr_think_time(26);

	web_submit_data("maximo.jsp_68", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx300\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonCompletion",LR_AUTO);

	lr_start_transaction("SelectSmartMeter");

	web_add_header("xhrseqnum", 
		"40");

	lr_think_time(29);

	web_submit_data("maximo.jsp_69", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8598", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8599\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"41");

	web_submit_data("maximo.jsp_70", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx12933[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx12933[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectSmartMeter",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"42");

	lr_think_time(22);

	web_submit_data("maximo.jsp_71", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx8598", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Changestatus_COMP");

	web_add_header("xhrseqnum", 
		"43");

	lr_think_time(25);

	web_submit_data("maximo.jsp_72", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13036", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13037\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"44");

	web_submit_data("maximo.jsp_73", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13036", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_COMP_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_COMP",LR_AUTO);

	lr_start_transaction("Clkok_COMP");

	web_add_header("xhrseqnum", 
		"45");

	lr_think_time(13);

	web_submit_data("maximo.jsp_74", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13091", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13091\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"46");

	web_submit_data("maximo.jsp_75", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13091", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"47");

	web_submit_data("maximo.jsp_76", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13091", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"48");

	web_submit_data("maximo.jsp_77", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13091", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"49");

	web_submit_data("maximo.jsp_78", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13091", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/st_MessageInformation.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		LAST);

	lr_end_transaction("Clkok_COMP",LR_AUTO);

	web_add_header("xhrseqnum", 
		"50");

	lr_think_time(24);

	web_submit_data("maximo.jsp_79", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx13145", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13145\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	lr_start_transaction("Logout");

	web_add_header("xhrseqnum", 
		"51");

	lr_think_time(15);

	web_submit_data("maximo.jsp_80", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=267", ENDITEM, 
		"Name=csrftoken", "Value=6k544bfh8i0h8rfj5656r8noj5", ENDITEM, 
		"Name=currentfocus", "Value=mx57", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx57\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"6k544bfh8i0h8rfj5656r8noj5\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("logout.jsp", 
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=267&csrftoken=6k544bfh8i0h8rfj5656r8noj5", 
		"Snapshot=t88.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}