Action()
{
	int i,j;
	
	web_set_max_html_param_len("1026");

/*Correlation comment - Do not change!  Original value='1526721557658' Name ='loginstamp' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=loginstamp",
		"TagName=input",
		"Extract=value",
		"Name=loginstamp",
		"Id=loginstamp",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/login.jsp*",
		LAST);
		
		lr_start_transaction("_Maximo_EmergencyWO_FSCH");


lr_start_transaction("Maximo_EmergencyWO_FSCH_Launch");


	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		LAST);
		
		lr_end_transaction("Maximo_EmergencyWO_FSCH_Launch", LR_AUTO);


	lr_think_time(18);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Login");

/*Correlation comment - Do not change!  Original value='6k544bfh8i0h8rfj5656r8noj5' Name ='csrftoken' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=csrftoken",
		"RegExp=csrftoken=(.*?)\";\\\n\\\t\\\t\\\tvar\\ XHRACTION\\ ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/login*",
		LAST);


web_reg_save_param("uisessionid","LB=maximo.jsp?uisessionid=","RB=&",LAST);

	web_submit_data("login",
		"Action=http://porud755/maximo/ui/login",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/webclient/login/login.jsp",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=allowinsubframe", "Value=null", ENDITEM,
		"Name=mobile", "Value=false", ENDITEM,
		"Name=login", "Value=jsp", ENDITEM,
		"Name=loginstamp", "Value={loginstamp}", ENDITEM,
		"Name=username", "Value=SP51532", ENDITEM,
		"Name=password", "Value=Deepya!1", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM,
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Login",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_GotoWorkorder");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(4);

	web_submit_data("maximo.jsp",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx45", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_url("ui",
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t6.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_GotoWorkorder",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_NewWO");
	
	web_reg_save_param("WorkOrder","LB=title=\"Work Order: ","RB=\" value=\"",LAST);
	
	

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(16);

	web_submit_data("maximo.jsp_2",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx527", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx314\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_NewWO",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_JobType");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_3",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1025", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1026\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_4",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t9.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1793[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1793[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_JobType",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_JobPriority");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(16);

	web_submit_data("maximo.jsp_5",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t10.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1274", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1275\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_6",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t11.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2015[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2015[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_JobPriority",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Startdate");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("blank.html",
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t12.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(7);

	web_custom_request("maximo.jsp_7",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t13.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus=mx1162&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1162%22%2C%22value%22%3A%22{Starttime}%2F{Month}%2F2018%20{schduletime}%3A{Currmins}%3A{Currsecs}%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%22{Starttime}%2F{Month}%2F2018%20{schduletime}%3A{Currmins}%3A{Currsecs}%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Startdate",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_EndDate");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(18);

	web_custom_request("maximo.jsp_8",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t14.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus=mx1170&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1170%22%2C%22value%22%3A%22{Enddate}%2F{Month}%2F2018%20{schduletime}%3A{Currmins}%3A{Currsecs}%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%22{Enddate}%2F{Month}%2F2018%20{schduletime}%3A{Currmins}%3A{Currsecs}%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_EndDate",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonAddress");

	web_add_header("xhrseqnum", 
		"8");

	lr_think_time(12);

	web_submit_data("maximo.jsp_9",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t15.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1170", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx297\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonAddress",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonNewRow");

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(14);

/*Correlation comment - Do not change!  Original value='mx2245' Name ='currentfocus_4' Type ='ResponseBased'*/
	web_reg_save_param_xpath(
		"ParamName=currentfocus_4",
		"QueryString=/server_response/compvalue/@id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("maximo.jsp_10",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t16.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2187", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2187\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonNewRow",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonGotoMeter");

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_11",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t17.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_4}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2246\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"11");

	web_submit_data("maximo.jsp_12",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t18.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_4}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_13",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t19.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonGotoMeter",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_London");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"3");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(17);
	
	web_reg_save_param("Address","LB=5px;;cursor:pointer;;;;\" title=\"","RB=\">","ORD=All",LAST);

	web_submit_data("maximo.jsp_14",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t20.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx538", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx538\",\"value\":\"London\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins/tivoli09/images/dialogclose.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/tabClose.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_think_time(15);

	web_submit_data("1526721769925",
		"Action=http://porud755/maximo/ui/1526721769925?checkhiddenandconnection=true&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t21.inf",
		"Mode=HTML",
		ITEMDATA,
		LAST);

	web_add_header("xhrseqnum", 
		"2");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");

	web_submit_data("maximo.jsp_15",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t22.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx538", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopquerycheck\",\"targetId\":\"query_longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/qf_clear.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_London",LR_AUTO);

/*lr_start_transaction("Maximo_EmergencyWO_FSCH_SelectCoutry");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(28);

	web_submit_data("maximo.jsp_16",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t23.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx93", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx93\",\"value\":\"W114594078\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"click\",\"targetId\":\"mx95\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/st_MessageCritical.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(6);

	web_submit_data("maximo.jsp_17",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t24.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx791", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx791\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_SelectCoutry",LR_AUTO);*/

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ProvideCountry");
	
	
	lr_save_string(lr_paramarr_random("Address"),"RandomParam"); 


	web_add_header("xhrseqnum", 
		"5");

	lr_think_time(29);

	web_submit_data("maximo.jsp_18",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t25.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx454", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx454\",\"value\":\"{RandomParam}\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ProvideCountry",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_SelectMPRN");

	web_add_header("xhrseqnum", 
		"6");

	lr_think_time(18);

	web_submit_data("maximo.jsp_19",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t26.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx576[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx576[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_SelectMPRN",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ReturnValue");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(16);

	web_submit_data("maximo.jsp_20",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t27.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx282", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

/*Correlation comment - Do not change!  Original value='mx298' Name ='currentfocus_2' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=currentfocus_2",
		"RegExp=tr\\ id=\"(.*?)\"\\ \\ control",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("maximo.jsp_21",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t28.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ReturnValue",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Plans");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");

	lr_think_time(17);

	web_submit_data("maximo.jsp_22",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t29.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_4}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/maximize.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/col_sort_asc.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_row_unselect.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/btn_garbage.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Plans",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_SelectLabor");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(20);

	web_submit_data("maximo.jsp_23",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t30.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx5807[R:0]\",\"value\":\"\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"click\",\"targetId\":\"mx5856[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_find.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_SelectLabor",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_GotoLabor");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(15);

	web_submit_data("maximo.jsp_24",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t31.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_25",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t32.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_GotoLabor",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonLabor");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"5");

	lr_think_time(23);

	web_submit_data("maximo.jsp_26",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t33.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx385\",\"value\":\"1\",\"requestType\":\"SYNC\",\"multi\":\"true\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonLabor",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_SelectLabor");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(33);

	web_submit_data("maximo.jsp_27",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t34.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx628[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx628[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_showvalue.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_checkedreadonly.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_SelectLabor",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Returvalue");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(17);

	web_submit_data("maximo.jsp_28",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t35.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_2}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{currentfocus_2}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("maximo.jsp_29",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=labor&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t36.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Returvalue",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"6");

	lr_think_time(16);

	web_submit_data("maximo.jsp_30",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t37.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Selectoption");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_31",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t38.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7214", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7215\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_32",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t39.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7214", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Selectoption",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonOk");
	
	web_reg_find("Text=Please wait","SaveCount=currstatus", "Search=All",LAST);

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(13);

	web_submit_data("maximo.jsp_33",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t40.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7269", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7269\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);
	
	if ((atoi(lr_eval_string("{currstatus}"))>0))
		
		
	{
		do
{
			i++;
			
	
			
    web_reg_find("Text=Status change(s) completed successfully","SaveCount=currstatus", "Search=All",LAST);
   // readonly="readonly" type="text" title="Status: FSCH" value="
   //web_reg_save_param("Status","LB=\"text\" title=\"","RB=\" value=\"",LAST);
	web_add_header("xhrseqnum", 
		"5");


	web_submit_data("maximo.jsp_34",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t41.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7269", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);
    
    	 }	while(atoi(lr_eval_string("{currstatus}"))==1);

	}
	



	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonOk",LR_AUTO);

/*lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkChangestatus");
	
	web_reg_find("Text=Record has been saved","SaveCount=Saved", "Search=All",LAST);
	
	

	web_add_header("xhrseqnum", 


		"6");

	lr_think_time(27);

	web_submit_data("maximo.jsp_35",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t42.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);
	
	
	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(12);

	web_submit_data("maximo.jsp_3",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t151.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx930", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);


	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkChangestatus",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Dispatch");

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(29);

	web_submit_data("maximo.jsp_36",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t43.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7377", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7378\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_37",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t44.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7377", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_DISPATCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Dispatch",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkOk_Dispatch");
	
	web_reg_find("Text=Please wait","SaveCount=Dispatchstatus", "Search=All",LAST);

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(18);

	web_submit_data("maximo.jsp_38",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t45.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7432\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);
	
	if ((atoi(lr_eval_string("{Dispatchstatus}"))>0))
		
		
	{
		do
{
			i++;
			
	
			
    web_reg_find("Text=Status change(s) completed successfully","SaveCount=Dispatchstatus", "Search=All",LAST);
    

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_39",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t46.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);
    
    	 }	while(atoi(lr_eval_string("{Dispatchstatus}"))==1);

	}

	/*web_add_header("xhrseqnum", 
		"11");

	web_submit_data("maximo.jsp_40",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t47.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"12");

	web_submit_data("maximo.jsp_41",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t48.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"13");

	web_submit_data("maximo.jsp_42",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t49.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"14");



	web_submit_data("maximo.jsp_43",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t50.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7432", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);
	
	 }	while(atoi(lr_eval_string("{Dispatchstatus}"))==1);

}


	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkOk_Dispatch",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"15");

	lr_think_time(19);

	web_submit_data("maximo.jsp_44",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t51.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Accept");

	web_add_header("xhrseqnum", 
		"16");

	lr_think_time(32);

	web_submit_data("maximo.jsp_45",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t52.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7548", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7549\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"17");

	web_submit_data("maximo.jsp_46",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t53.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7548", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ACCEPT_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Accept",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Clkok_Accept");

	web_add_header("xhrseqnum", 
		"18");

	lr_think_time(13);

	web_submit_data("maximo.jsp_47",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t54.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7603", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7603\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"19");

	web_submit_data("maximo.jsp_48",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t55.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7603", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_BacktoWO");

	web_add_header("xhrseqnum", 
		"20");

	lr_think_time(14);

	web_submit_data("maximo.jsp_49",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t56.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx5855[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx279\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_BacktoWO",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changedetails");

	web_add_header("xhrseqnum", 
		"21");

	lr_think_time(17);

	web_submit_data("maximo.jsp_50",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t57.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1473", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1474\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"22");

	web_submit_data("maximo.jsp_51",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t58.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7789[R:1]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7789[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"23");

	web_submit_data("maximo.jsp_52",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t59.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1481", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1482\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"24");

	web_submit_data("maximo.jsp_53",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t60.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx7970[R:1]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7970[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"25");

	web_submit_data("maximo.jsp_54",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t61.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1492", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1493\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"26");

	web_submit_data("maximo.jsp_55",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t62.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8151[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8151[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changedetails",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"27");

	lr_think_time(21);

	web_submit_data("maximo.jsp_56",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t63.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1492", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Complete");

	web_add_header("xhrseqnum", 
		"28");

	lr_think_time(35);

	web_submit_data("maximo.jsp_57",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t64.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8254", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8255\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"29");

	lr_think_time(4);

	web_submit_data("maximo.jsp_58",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t65.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8254", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ONSITE_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"30");

	lr_think_time(5);

	web_submit_data("maximo.jsp_59",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t66.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8309", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8309\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"31");

	web_submit_data("maximo.jsp_60",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t67.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8309", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changestatus_Complete",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus_COMP");

	web_add_header("xhrseqnum", 
		"32");

	lr_think_time(18);

	web_submit_data("maximo.jsp_61",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t68.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus_COMP",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changestatus_COMP");

	web_add_header("xhrseqnum", 
		"33");

	lr_think_time(13);

	web_submit_data("maximo.jsp_62",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t69.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8417", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8418\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"34");

	web_submit_data("maximo.jsp_63",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t70.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8417", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_COMP_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changestatus_COMP",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Clkok_COMP");

	web_add_header("xhrseqnum", 
		"35");

	lr_think_time(14);

	web_submit_data("maximo.jsp_64",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t71.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8472", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8472\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"36");

	web_submit_data("maximo.jsp_65",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t72.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8472", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"37");

	lr_think_time(21);

	web_submit_data("maximo.jsp_66",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t73.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8520", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8520\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"38");

	web_submit_data("maximo.jsp_67",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t74.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8474", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8474\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Clkok_COMP",LR_AUTO);

lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonCompletion");

	web_add_header("xhrseqnum", 
		"39");

	lr_think_time(26);

	web_submit_data("maximo.jsp_68",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t75.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1492", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx300\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonCompletion",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_SelectSmartMeter");

	web_add_header("xhrseqnum", 
		"40");

	lr_think_time(29);

	web_submit_data("maximo.jsp_69",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t76.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8598", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx8599\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"41");

	web_submit_data("maximo.jsp_70",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t77.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx12933[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx12933[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_SelectSmartMeter",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"42");

	lr_think_time(22);

	web_submit_data("maximo.jsp_71",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t78.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx8598", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Changestatus_COMP");

	web_add_header("xhrseqnum", 
		"43");

	lr_think_time(25);

	web_submit_data("maximo.jsp_72",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t79.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13036", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13037\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"44");

	web_submit_data("maximo.jsp_73",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t80.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13036", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_COMP_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Changestatus_COMP",LR_AUTO);

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Clkok_COMP");

	web_add_header("xhrseqnum", 
		"45");

	lr_think_time(13);

	web_submit_data("maximo.jsp_74",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t81.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13091", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13091\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"46");

	web_submit_data("maximo.jsp_75",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t82.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13091", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"47");

	web_submit_data("maximo.jsp_76",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t83.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13091", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"48");

	web_submit_data("maximo.jsp_77",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t84.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13091", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"49");

	web_submit_data("maximo.jsp_78",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t85.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13091", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/st_MessageInformation.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Clkok_COMP",LR_AUTO);

	web_add_header("xhrseqnum", 
		"50");

	lr_think_time(24);

	web_submit_data("maximo.jsp_79",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t86.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx13145", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx13145\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);*/

	lr_start_transaction("Maximo_EmergencyWO_FSCH_Logout");

	web_add_header("xhrseqnum", 
		"51");

	lr_think_time(15);

	web_submit_data("maximo.jsp_80",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t87.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx57", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx57\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("logout.jsp",
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t88.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmergencyWO_FSCH_Logout",LR_AUTO);
	
	lr_end_transaction("_Maximo_EmergencyWO_FSCH", LR_AUTO);
	
	WriteVTS(lr_eval_string("{WorkOrder}"),"EMWorkOrder");


	return 0;
}